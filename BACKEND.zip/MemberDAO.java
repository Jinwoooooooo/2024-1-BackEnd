/**===========================
 * 작성자 : jinsook
 * 작성일 : 2024. 5. 21.
 * 기능 : Member 테이블 관린(insert, list, update, selectOne, delete)
 =============================*/
package cs.dit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

public class MemberDAO {
	
	//Connection 객체를 가져오기 
	//1. 접극제어자 : private/public
	//2. 리턴타입
	//3. 파라미저(입력 데이터)
	//4. 출력
	
	private Connection getConnection() throws Exception{
	 	//커넥션 풀을 사용하여 DB와 연동
	 	Context initCtx = new InitialContext();
	 	Context ctx = (Context)initCtx.lookup("java:comp/env");
	 	DataSource ds = (DataSource)ctx.lookup("jdbc/jinwoo");
	 	Connection con = ds.getConnection();
	 	
		return con;
	}
	//전송된 데이터를 데이터베이스에 입력
	public void insert(MemberDTO dto) {
		//3. 생성된 연결을 통해 SQL문 실행 의뢰 준비
		String sql = "INSERT INTO LOGIN(id,name,pwd) VALUES(?,?,?)";
		
		try(Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);) 
		{			
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getPwd());
			//4. SQL 실행
			pstmt.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//데이터베이스에 있는 데이터를 가져오기
	public ArrayList<MemberDTO> list(){
		ArrayList<MemberDTO> dtos = new ArrayList<MemberDTO>();
		String sql = "SELECT id, pwd,name FROM login";
		
		//커넥션 가져오기
		try(Connection con = getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
		) {
			while (rs.next()){
				MemberDTO dto = new MemberDTO(rs.getString("id"), rs.getString("pwd"),rs.getString("name"));
//				dto.setId(rs.getString("id"));
//				dto.setPwd(rs.getString("pwd"));
//				dto.setName(rs.getString("name"));
				
				dtos.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return dtos;
	}
	
	public MemberDTO selectOne(String id) {
		MemberDTO dto = null;
		String sql = "select * from login where id = ?";
		
		try(Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);) 
		{	pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()){
				dto = new MemberDTO(id, rs.getString("name"), rs.getString("pwd"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return dto;
	}
	//Login 데이터를 변경하는 메소드
	public void update(MemberDTO dto) {
		String sql = "UPDATE login SET name = ?, pwd = ? WHERE id =?";
		
		try (
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
		)
		{
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	//Login 데이터 삭제 메소드
	public void delete(String id) {
		String sql = "DELETE FROM login WHERE id =?";
		
		try (
			Connection con = getConnection();
			PreparedStatement pstmt = con.prepareStatement(sql);
		)
		{
			pstmt.setString(1, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}












