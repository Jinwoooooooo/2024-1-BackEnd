/**===========================
 * 작성자 : jinsook
 * 작성일 : 2024. 5. 21.
 * 기능 : 사용자의 데이터를 저장하는 객체
 =============================*/
package cs.dit;

public class MemberDTO {
	//멤버변수
	private String id;
	private String pwd;
	private String name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MemberDTO() {}

	public MemberDTO(String id, String pwd, String name) {
		this.id = id;
		this.pwd = pwd;
		this.name = name;
	}

	
	
}
